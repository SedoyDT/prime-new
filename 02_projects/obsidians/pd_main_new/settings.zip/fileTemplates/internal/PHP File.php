<?php
/**
 * Все права на программный код принадлежат ООО "ПИАР СИТИ"
 *
 * @author Frolov Anatolui
 * @date ${DATE}
 * @copyright Copyright (c) ООО "ПИАР СИТИ" project AMDSolution
 */
